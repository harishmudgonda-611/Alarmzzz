package com.alarmzzz;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    SharedPreferences p;
    TextView st;
    EditText partnerEt;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS,
                    Manifest.permission.ACTIVITY_RECOGNITION}, 1);
        else
            requestPermissions(new String[]{Manifest.permission.ACTIVITY_RECOGNITION}, 1);
        p = getSharedPreferences("a", 0);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER_HORIZONTAL);
        l.setPadding(48, 48, 48, 48);
        TextView h = new TextView(this);
        h.setText("Alarmzzz"); h.setTextSize(32); h.setGravity(Gravity.CENTER);
        TextView sub = new TextView(this);
        sub.setText("Snooze Is Dead"); sub.setTextSize(16); sub.setGravity(Gravity.CENTER);
        final TimePicker tp = new TimePicker(this);
        tp.setHour(p.getInt("h", 7)); tp.setMinute(p.getInt("m", 0));
        st = new TextView(this);
        st.setTextSize(18); st.setGravity(Gravity.CENTER);
        show();
        Button on = new Button(this); on.setText("Set alarm");
        Button off = new Button(this); off.setText("Turn off");
        on.setOnClickListener(v -> { Alarms.set(this, tp.getHour(), tp.getMinute()); show(); });
        off.setOnClickListener(v -> { Alarms.cancel(this); show(); });

        partnerEt = new EditText(this);
        partnerEt.setHint("Partner's name (optional)");
        partnerEt.setText(p.getString("partner", ""));
        Button invite = new Button(this); invite.setText("Invite a partner");
        invite.setOnClickListener(v -> {
            savePartner();
            Intent s = new Intent(Intent.ACTION_SEND);
            s.setType("text/plain");
            s.putExtra(Intent.EXTRA_TEXT, "Let's both wake up on time! Alarmzzz: Snooze Is Dead is an alarm that only stops when you drink water and walk 10 steps. Try it with me.");
            startActivity(Intent.createChooser(s, "Invite"));
        });

        TextView tip = new TextView(this);
        tip.setText("Tip: on Xiaomi, Oppo, Vivo, Samsung and similar phones, set Alarmzzz battery to Unrestricted so the alarm always rings.");
        tip.setGravity(Gravity.CENTER);
        tip.setPadding(0, 32, 0, 8);
        Button bat = new Button(this); bat.setText("Open battery settings");
        bat.setOnClickListener(v -> startActivity(
                new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)));
        l.addView(h); l.addView(sub); l.addView(tp); l.addView(st);
        l.addView(on); l.addView(off);
        l.addView(partnerEt); l.addView(invite);
        l.addView(tip); l.addView(bat);
        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        setContentView(sv);
    }

    void savePartner() {
        p.edit().putString("partner", partnerEt.getText().toString().trim()).apply();
    }

    void show() {
        int n = Streak.current(this);
        String a = p.getBoolean("on", false)
                ? String.format("Alarm set for %02d:%02d daily", p.getInt("h", 7), p.getInt("m", 0))
                : "No alarm set";
        st.setText(a + "\nStreak: " + n + (n == 1 ? " day" : " days"));
    }

    @Override protected void onResume() { super.onResume(); show(); }

    @Override protected void onPause() { savePartner(); super.onPause(); }
}
