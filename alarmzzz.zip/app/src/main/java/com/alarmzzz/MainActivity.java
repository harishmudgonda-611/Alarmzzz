package com.alarmzzz;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.*;
import java.util.List;

public class MainActivity extends Activity {
    SharedPreferences p;
    LinearLayout root;
    EditText partnerEt;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS,
                    Manifest.permission.ACTIVITY_RECOGNITION}, 1);
        else
            requestPermissions(new String[]{Manifest.permission.ACTIVITY_RECOGNITION}, 1);
        p = getSharedPreferences("a", 0);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        // cancel the single alarm used by older versions
        ((AlarmManager) getSystemService(ALARM_SERVICE)).cancel(PendingIntent.getBroadcast(this, 2,
                new Intent(this, AlarmReceiver.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pd = Ui.dp(this, 16);
        root.setPadding(pd, Ui.dp(this, 28), pd, pd);
        root.setFocusableInTouchMode(true);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.BG);
        sv.setFillViewport(true);
        sv.addView(root);
        setContentView(sv);
    }

    @Override protected void onResume() { super.onResume(); render(); }

    @Override protected void onPause() { savePartner(); super.onPause(); }

    void savePartner() {
        if (partnerEt != null)
            p.edit().putString("partner", partnerEt.getText().toString().trim()).apply();
    }

    static String left(long ms) {
        long m = Math.max(1, ms / 60000);
        return m >= 60 ? (m / 60) + "h " + (m % 60) + "m" : m + "m";
    }

    void render() {
        savePartner();
        root.removeAllViews();
        root.addView(Ui.tv(this, "Alarmzzz", 34, Ui.TXT, true));
        root.addView(Ui.tv(this, "Snooze Is Dead", 14, Ui.SUB, false));

        LinearLayout sc = Ui.card(this);
        long nx = Alarms.nextAny(this);
        int n = Streak.current(this);
        sc.addView(Ui.tv(this, nx < 0 ? "No alarm set"
                : "Next alarm in " + left(nx - System.currentTimeMillis()), 20, Ui.TXT, true));
        sc.addView(Ui.tv(this, "Streak: " + n + (n == 1 ? " day" : " days"), 15, Ui.SUB, false));
        root.addView(sc);

        List<Alarm> list = Alarms.load(this);
        for (final Alarm a : list) {
            LinearLayout c = Ui.card(this);
            c.setOrientation(LinearLayout.HORIZONTAL);
            c.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout left = new LinearLayout(this);
            left.setOrientation(LinearLayout.VERTICAL);
            left.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
            left.addView(Ui.tv(this, a.time(), 30, a.on ? Ui.TXT : Ui.SUB, true));
            left.addView(Ui.tv(this, (a.label.isEmpty() ? "" : a.label + " - ") + a.daysText(),
                    14, Ui.SUB, false));
            Switch sw = new Switch(this);
            sw.setChecked(a.on);
            sw.setOnCheckedChangeListener((v, ch) -> {
                a.on = ch;
                Alarms.upsert(this, a);
                root.post(this::render);
            });
            c.addView(left);
            c.addView(sw);
            c.setOnClickListener(v -> edit(a));
            root.addView(c);
        }
        Button add = Ui.btn(this, "+ New alarm", true);
        add.setOnClickListener(v -> edit(new Alarm()));
        root.addView(add);

        LinearLayout pc = Ui.card(this);
        pc.addView(Ui.tv(this, "Wake up with a partner", 18, Ui.TXT, true));
        pc.addView(Ui.tv(this, "Share your streak after every morning. Add a name to personalise the message.",
                13, Ui.SUB, false));
        partnerEt = new EditText(this);
        partnerEt.setHint("Partner's name (optional)");
        partnerEt.setHintTextColor(Ui.SUB);
        partnerEt.setTextColor(Ui.TXT);
        partnerEt.setText(p.getString("partner", ""));
        pc.addView(partnerEt);
        Button invite = Ui.btn(this, "Invite a partner", false);
        invite.setOnClickListener(v -> {
            savePartner();
            Intent s = new Intent(Intent.ACTION_SEND);
            s.setType("text/plain");
            s.putExtra(Intent.EXTRA_TEXT, "Let's both wake up on time! Alarmzzz: Snooze Is Dead is an alarm that only stops when you drink water and walk 10 steps. Try it with me.");
            startActivity(Intent.createChooser(s, "Invite"));
        });
        pc.addView(invite);
        root.addView(pc);

        LinearLayout bc = Ui.card(this);
        bc.addView(Ui.tv(this, "Make sure the alarm rings", 18, Ui.TXT, true));
        bc.addView(Ui.tv(this, "On Xiaomi, Oppo, Vivo, Samsung and similar phones, set Alarmzzz battery to Unrestricted.",
                13, Ui.SUB, false));
        Button bat = Ui.btn(this, "Open battery settings", false);
        bat.setOnClickListener(v -> startActivity(
                new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)));
        bc.addView(bat);
        root.addView(bc);
        root.requestFocus();
    }

    void paint(Button b, boolean on) {
        b.setBackground(Ui.box(this, on ? Ui.ACC : 0xFF2A2E38, 12));
    }

    void edit(final Alarm a) {
        final boolean isNew = a.id == 0;
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        int pd = Ui.dp(this, 16);
        v.setPadding(pd, pd, pd, 0);
        final Button tb = Ui.btn(this, a.time(), false);
        tb.setTextSize(28);
        tb.setOnClickListener(x -> new TimePickerDialog(this, (tp, hh, mm) -> {
            a.h = hh;
            a.m = mm;
            tb.setText(a.time());
        }, a.h, a.m, false).show());
        final EditText et = new EditText(this);
        et.setHint("Label (e.g. Gym)");
        et.setText(a.label);
        LinearLayout row = new LinearLayout(this);
        String[] names = {"S", "M", "T", "W", "T", "F", "S"};
        for (int i = 0; i < 7; i++) {
            final int bit = 1 << i;
            Button cb = new Button(this);
            cb.setText(names[i]);
            cb.setAllCaps(false);
            cb.setTextColor(Ui.TXT);
            cb.setPadding(0, 0, 0, 0);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(this, 44), 1f);
            lp.setMargins(2, 0, 2, 0);
            cb.setLayoutParams(lp);
            paint(cb, (a.days & bit) != 0);
            cb.setOnClickListener(x -> {
                a.days ^= bit;
                paint((Button) x, (a.days & bit) != 0);
            });
            row.addView(cb);
        }
        final CheckBox cw = new CheckBox(this);
        cw.setText("Drink water challenge");
        cw.setChecked(a.water);
        cw.setOnCheckedChangeListener((x, ch) -> a.water = ch);
        final Button sb = Ui.btn(this, "Steps to walk: " + a.steps, false);
        sb.setOnClickListener(x -> {
            a.steps = a.steps >= 30 ? 10 : a.steps + 10;
            sb.setText("Steps to walk: " + a.steps);
        });
        v.addView(tb);
        v.addView(et);
        v.addView(Ui.tv(this, "Repeat (none selected = once)", 13, Ui.SUB, false));
        v.addView(row);
        v.addView(cw);
        v.addView(sb);
        ScrollView s = new ScrollView(this);
        s.addView(v);
        AlertDialog.Builder bd = new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(isNew ? "New alarm" : "Edit alarm")
                .setView(s)
                .setPositiveButton("Save", (d, w) -> {
                    a.label = et.getText().toString().trim();
                    a.on = true;
                    Alarms.upsert(this, a);
                    render();
                })
                .setNegativeButton("Cancel", (d, w) -> render());
        if (!isNew) bd.setNeutralButton("Delete", (d, w) -> {
            Alarms.delete(this, a.id);
            render();
        });
        bd.show();
    }
}
