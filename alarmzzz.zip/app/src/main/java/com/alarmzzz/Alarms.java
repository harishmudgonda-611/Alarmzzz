package com.alarmzzz;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;

class Alarms {
    static List<Alarm> load(Context c) {
        List<Alarm> l = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(c.getSharedPreferences("a", 0).getString("list", "[]"));
            for (int i = 0; i < a.length(); i++) l.add(Alarm.from(a.getJSONObject(i)));
        } catch (Exception e) { }
        return l;
    }

    static void save(Context c, List<Alarm> l) {
        try {
            JSONArray a = new JSONArray();
            for (Alarm x : l) a.put(x.toJson());
            c.getSharedPreferences("a", 0).edit().putString("list", a.toString()).apply();
        } catch (Exception e) { }
    }

    static Alarm get(Context c, int id) {
        for (Alarm x : load(c)) if (x.id == id) return x;
        return null;
    }

    static void upsert(Context c, Alarm a) {
        List<Alarm> l = load(c);
        if (a.id == 0) {
            int max = 0;
            for (Alarm x : l) max = Math.max(max, x.id);
            a.id = max + 1;
            l.add(a);
        } else {
            for (int i = 0; i < l.size(); i++) if (l.get(i).id == a.id) l.set(i, a);
        }
        save(c, l);
        schedule(c, a);
    }

    static void delete(Context c, int id) {
        cancel(c, id);
        List<Alarm> l = load(c);
        for (Iterator<Alarm> i = l.iterator(); i.hasNext(); ) if (i.next().id == id) i.remove();
        save(c, l);
    }

    static PendingIntent op(Context c, int id) {
        Intent i = new Intent(c, AlarmReceiver.class).putExtra("id", id);
        return PendingIntent.getBroadcast(c, id, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static void cancel(Context c, int id) {
        ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).cancel(op(c, id));
    }

    static void schedule(Context c, Alarm a) {
        cancel(c, a.id);
        if (!a.on) return;
        long t = a.next();
        if (t < 0) return;
        PendingIntent show = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE);
        ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE))
                .setAlarmClock(new AlarmManager.AlarmClockInfo(t, show), op(c, a.id));
    }

    static void scheduleAll(Context c) {
        for (Alarm a : load(c)) schedule(c, a);
    }

    static long nextAny(Context c) {
        long best = -1;
        for (Alarm a : load(c)) {
            if (!a.on) continue;
            long t = a.next();
            if (t > 0 && (best < 0 || t < best)) best = t;
        }
        return best;
    }
}
