package com.alarmzzz;

import android.content.Context;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class Streak {
    static String day(int offset) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, offset);
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.getTime());
    }

    static int complete(Context c) {
        SharedPreferences p = c.getSharedPreferences("a", 0);
        String last = p.getString("lastDone", "");
        int n = p.getInt("streak", 0);
        if (last.equals(day(0))) return Math.max(n, 1);
        n = last.equals(day(-1)) ? n + 1 : 1;
        p.edit().putString("lastDone", day(0)).putInt("streak", n).apply();
        return n;
    }

    static int current(Context c) {
        SharedPreferences p = c.getSharedPreferences("a", 0);
        String last = p.getString("lastDone", "");
        return (last.equals(day(0)) || last.equals(day(-1))) ? p.getInt("streak", 0) : 0;
    }
}
