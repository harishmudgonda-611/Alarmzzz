package com.alarmzzz;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;

public class AlarmActivity extends Activity implements SensorEventListener {
    static final long EMERGENCY_AFTER_MS = 5 * 60 * 1000;
    static final long HOLD_MS = 10 * 1000;
    static final long MIN_STEP_GAP_MS = 400;

    TextView title, info;
    Button btn, emerg, close;
    SensorManager sm;
    int steps = 0;
    long lastStep = 0;
    boolean finished = false;
    Handler h = new Handler(Looper.getMainLooper());
    Runnable stopNow = () -> abort();
    Runnable showEmerg = () -> emerg.setVisibility(View.VISIBLE);

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setShowWhenLocked(true);
        setTurnScreenOn(true);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        l.setPadding(48, 48, 48, 48);
        title = new TextView(this); title.setTextSize(30); title.setGravity(Gravity.CENTER);
        info = new TextView(this); info.setTextSize(24); info.setGravity(Gravity.CENTER);
        btn = new Button(this); btn.setTextSize(20);
        close = new Button(this); close.setText("Close");
        close.setVisibility(View.GONE);
        close.setOnClickListener(v -> finish());
        emerg = new Button(this);
        emerg.setText("Emergency stop (hold 10 sec)");
        emerg.setVisibility(View.GONE);
        emerg.setOnTouchListener((v, e) -> {
            int a = e.getAction();
            if (a == MotionEvent.ACTION_DOWN) {
                emerg.setText("Keep holding...");
                h.postDelayed(stopNow, HOLD_MS);
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                emerg.setText("Emergency stop (hold 10 sec)");
                h.removeCallbacks(stopNow);
            }
            return true;
        });
        l.addView(title); l.addView(info); l.addView(btn); l.addView(close); l.addView(emerg);
        setContentView(l);
        long start = getSharedPreferences("a", 0).getLong("ringStart", System.currentTimeMillis());
        long wait = Math.max(0, EMERGENCY_AFTER_MS - (System.currentTimeMillis() - start));
        h.postDelayed(showEmerg, wait);
        showWater();
    }

    void showWater() {
        title.setText("Step 1: Drink a glass of water");
        info.setText("Then tap the button");
        btn.setText("I drank water");
        btn.setOnClickListener(v -> startWalk());
    }

    void startWalk() {
        title.setText("Step 2: Walk 10 steps");
        info.setText("0 / 10");
        btn.setVisibility(View.GONE);
        sm = getSystemService(SensorManager.class);
        Sensor s = sm.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
        boolean ok = checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION)
                == PackageManager.PERMISSION_GRANTED;
        if (s != null && ok) {
            sm.registerListener(this, s, SensorManager.SENSOR_DELAY_FASTEST);
        } else {
            info.setText("Step sensor not available. This morning will not count toward your streak.");
            btn.setVisibility(View.VISIBLE);
            btn.setText("Stop alarm");
            btn.setOnClickListener(v -> abort());
        }
    }

    @Override public void onSensorChanged(SensorEvent e) {
        long now = SystemClock.elapsedRealtime();
        if (now - lastStep < MIN_STEP_GAP_MS) return;
        lastStep = now;
        steps++;
        info.setText(steps + " / 10");
        if (steps >= 10) success();
    }

    @Override public void onAccuracyChanged(Sensor s, int a) { }

    void stopAll() {
        h.removeCallbacksAndMessages(null);
        if (sm != null) sm.unregisterListener(this);
        stopService(new Intent(this, AlarmService.class));
    }

    void abort() {
        stopAll();
        finish();
    }

    void success() {
        stopAll();
        finished = true;
        final int n = Streak.complete(this);
        emerg.setVisibility(View.GONE);
        title.setText("You're up! Snooze is dead.");
        info.setText("Streak: " + n + (n == 1 ? " day" : " days"));
        btn.setVisibility(View.VISIBLE);
        btn.setText("Share with partner");
        btn.setOnClickListener(v -> share(n));
        close.setVisibility(View.VISIBLE);
    }

    void share(int n) {
        String partner = getSharedPreferences("a", 0).getString("partner", "");
        String msg = (partner.isEmpty() ? "" : "Hey " + partner + "! ")
                + "I'm up! Alarmzzz streak: " + n + (n == 1 ? " day" : " days")
                + ". Snooze is dead. Are you up yet?";
        Intent s = new Intent(Intent.ACTION_SEND);
        s.setType("text/plain");
        s.putExtra(Intent.EXTRA_TEXT, msg);
        startActivity(Intent.createChooser(s, "Share"));
    }

    @Override protected void onDestroy() {
        h.removeCallbacksAndMessages(null);
        if (sm != null) sm.unregisterListener(this);
        super.onDestroy();
    }

    @Override public void onBackPressed() { if (finished) finish(); }
}
