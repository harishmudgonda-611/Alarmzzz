package com.alarmzzz;

import java.util.Calendar;
import org.json.JSONObject;

class Alarm {
    int id, h = 7, m = 0, days = 0, steps = 10; // days: bit0=Sun..bit6=Sat, 0 = once
    boolean on = true, water = true;
    String label = "";

    JSONObject toJson() throws Exception {
        JSONObject o = new JSONObject();
        o.put("id", id).put("h", h).put("m", m).put("days", days).put("steps", steps)
                .put("on", on).put("water", water).put("label", label);
        return o;
    }

    static Alarm from(JSONObject o) {
        Alarm a = new Alarm();
        a.id = o.optInt("id");
        a.h = o.optInt("h", 7);
        a.m = o.optInt("m");
        a.days = o.optInt("days");
        a.steps = o.optInt("steps", 10);
        a.on = o.optBoolean("on", true);
        a.water = o.optBoolean("water", true);
        a.label = o.optString("label", "");
        return a;
    }

    long next() {
        long now = System.currentTimeMillis();
        for (int i = 0; i < 8; i++) {
            Calendar t = Calendar.getInstance();
            t.add(Calendar.DAY_OF_YEAR, i);
            t.set(Calendar.HOUR_OF_DAY, h);
            t.set(Calendar.MINUTE, m);
            t.set(Calendar.SECOND, 0);
            t.set(Calendar.MILLISECOND, 0);
            int dow = t.get(Calendar.DAY_OF_WEEK) - 1;
            boolean ok = days == 0 || (days & (1 << dow)) != 0;
            if (ok && t.getTimeInMillis() > now) return t.getTimeInMillis();
        }
        return -1;
    }

    String time() {
        int hh = h % 12 == 0 ? 12 : h % 12;
        return hh + ":" + String.format("%02d", m) + (h < 12 ? " AM" : " PM");
    }

    String daysText() {
        if (days == 0) return "Once";
        if (days == 127) return "Every day";
        String[] n = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < 7; i++) {
            if ((days & (1 << i)) != 0) {
                if (s.length() > 0) s.append(", ");
                s.append(n[i]);
            }
        }
        return s.toString();
    }
}
