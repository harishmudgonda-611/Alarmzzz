package com.alarmzzz;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        SharedPreferences p = c.getSharedPreferences("a", 0);
        if (p.getBoolean("on", false)) Alarms.set(c, p.getInt("h", 7), p.getInt("m", 0));
        c.startForegroundService(new Intent(c, AlarmService.class));
    }
}
