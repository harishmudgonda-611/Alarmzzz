package com.alarmzzz;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        int id = i.getIntExtra("id", 0);
        Alarm a = Alarms.get(c, id);
        if (a == null || !a.on) return;
        if (a.days == 0) {
            a.on = false;
            Alarms.upsert(c, a);
        } else {
            Alarms.schedule(c, a);
        }
        c.startForegroundService(new Intent(c, AlarmService.class).putExtra("id", id));
    }
}
